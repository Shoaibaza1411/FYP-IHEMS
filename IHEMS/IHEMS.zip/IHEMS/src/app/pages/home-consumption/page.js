"use client";
import HomeConsumption from "@/app/components/HomeConsumption";


export default function HomeConsumptionPage() {

  return (
    <div>
      <HomeConsumption />
    </div>
  );
}
