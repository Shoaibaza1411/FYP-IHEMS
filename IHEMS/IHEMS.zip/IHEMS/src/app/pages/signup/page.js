"use client"
import React from "react";
import { useRouter } from "next/navigation"; // Import useRouter hook
import "./style.css";

export default function SignUp() {
  const router = useRouter();

  // Function to handle navigation to the dashboard
  const navigateToDashboard = () => {
    router.push("/pages/dashboard");
  };

  return (
    <div className="flex justify-center items-center mt-8">
      <div className="main">
        <input className="inputField" type="checkbox" id="chk" aria-hidden="true" />

        <div className="signup">
          <form>
            <label htmlFor="chk" aria-hidden="true">
              <h1 className="text-emerald-500">Sign Up</h1>
            </label>
            <input className="inputField" type="text" name="txt" placeholder="User name" required="" />
            <input className="inputField" type="email" name="email" placeholder="Email" required="" />
            <input className="inputField"
              type="number"
              name="broj"
              placeholder="Phone No"
              required=""
            />
            <input className="inputField"
              type="password"
              name="pswd"
              placeholder="Password"
              required=""
            />
            <button
              className="btn"
              type="button"
              onClick={navigateToDashboard} // Navigate to the dashboard on click
            >
              Sign up
            </button>
          </form>
        </div>

        <div className="login">
          <form>
            <label htmlFor="chk" aria-hidden="true">
              Login
            </label>
            <input className="inputField" type="email" name="email" placeholder="Email" required="" />
            <input className="inputField"
              type="password"
              name="pswd"
              placeholder="Password"
              required=""
            />
            <button
              className="btn"
              type="button"
              onClick={navigateToDashboard} // Navigate to the dashboard on click
            >
              Login
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
