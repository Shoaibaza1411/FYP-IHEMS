import SignUp from "./pages/signup/page";

export default function Home() {
  return (
    <>
    <SignUp/>
    </>
  );
}
